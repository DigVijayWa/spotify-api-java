public interface ApiInterface {

  public static final String apiSearch = "https://api.spotify.com/v1/search";

  public static final String albumSearch = "https://api.spotify.com/v1/albums";
}
